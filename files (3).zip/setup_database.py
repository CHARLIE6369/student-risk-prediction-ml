"""
==============================================
STUDENT PERFORMANCE PREDICTION SYSTEM
Step 1: Database Setup with Sample Data
==============================================

HOW TO RUN:
    python setup_database.py

This script will:
1. Create a SQLite database file called 'students.db'
2. Create the 'students' and 'predictions' tables
3. Insert 20 sample student records
4. Print a confirmation with the data

REQUIREMENTS:
    - Python 3.x (sqlite3 is built-in, no install needed!)
"""

import sqlite3      # built into Python — no pip install needed
import random       # to generate random sample data
import os           # to check if database file already exists


# ─────────────────────────────────────────────────────────
# STEP 1A: Connect to the database
# ─────────────────────────────────────────────────────────
# sqlite3.connect() creates 'students.db' file if it doesn't exist
# If the file already exists, it just opens it
db_path = "students.db"
connection = sqlite3.connect(db_path)

# A 'cursor' is like a pen — we use it to write SQL commands
cursor = connection.cursor()

print("✅ Connected to database:", db_path)


# ─────────────────────────────────────────────────────────
# STEP 1B: Create tables
# ─────────────────────────────────────────────────────────
# We use triple quotes (""") for multi-line SQL strings
# IF NOT EXISTS means: only create if table doesn't already exist

cursor.execute("""
    CREATE TABLE IF NOT EXISTS students (
        student_id      INTEGER PRIMARY KEY AUTOINCREMENT,
        name            TEXT NOT NULL,
        gender          TEXT NOT NULL,
        attendance_pct  REAL NOT NULL,
        study_hours     REAL NOT NULL,
        assignments     INTEGER NOT NULL,
        internal_marks  REAL NOT NULL,
        backlogs        INTEGER NOT NULL,
        at_risk         INTEGER NOT NULL
    )
""")

cursor.execute("""
    CREATE TABLE IF NOT EXISTS predictions (
        pred_id         INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id      INTEGER,
        predicted_label INTEGER,
        confidence      REAL,
        predicted_on    TEXT,
        FOREIGN KEY (student_id) REFERENCES students(student_id)
    )
""")

print("✅ Tables created successfully!")


# ─────────────────────────────────────────────────────────
# STEP 1C: Insert sample student data
# ─────────────────────────────────────────────────────────
# This is a list of tuples — each tuple = one student row
# Format: (name, gender, attendance_pct, study_hours,
#           assignments, internal_marks, backlogs, at_risk)

sample_students = [
    # Good students (at_risk = 0)
    ("Aarav Sharma",    "Male",   91.5, 5.0, 10, 44.0, 0, 0),
    ("Priya Nair",      "Female", 88.0, 4.5,  9, 41.5, 0, 0),
    ("Rohan Mehta",     "Male",   85.0, 4.0,  9, 39.0, 0, 0),
    ("Sneha Iyer",      "Female", 92.0, 5.5, 10, 46.0, 0, 0),
    ("Karan Verma",     "Male",   78.0, 3.5,  8, 36.5, 0, 0),
    ("Divya Pillai",    "Female", 82.0, 4.0,  9, 38.0, 0, 0),
    ("Arjun Tiwari",    "Male",   89.0, 4.5, 10, 43.0, 0, 0),
    ("Meera Joshi",     "Female", 86.0, 4.0,  8, 40.0, 0, 0),
    ("Nikhil Patel",    "Male",   80.5, 3.8,  9, 37.5, 0, 0),
    ("Ananya Singh",    "Female", 93.0, 5.0, 10, 47.0, 0, 0),

    # At-risk students (at_risk = 1)
    ("Raju Yadav",      "Male",   42.0, 1.0,  2, 14.0, 3, 1),
    ("Sunita Kumari",   "Female", 55.0, 1.5,  3, 18.5, 2, 1),
    ("Deepak Gupta",    "Male",   38.0, 0.5,  1, 11.0, 4, 1),
    ("Kavita Reddy",    "Female", 61.0, 2.0,  4, 22.0, 2, 1),
    ("Suresh Babu",     "Male",   48.0, 1.0,  2, 15.5, 3, 1),
    ("Pooja Mishra",    "Female", 52.0, 1.5,  3, 19.0, 2, 1),
    ("Amit Rawat",      "Male",   35.0, 0.5,  1,  9.5, 5, 1),
    ("Nisha Chauhan",   "Female", 59.0, 2.0,  4, 21.0, 1, 1),
    ("Vikas Rao",       "Male",   44.0, 1.0,  2, 13.0, 3, 1),
    ("Lalita Devi",     "Female", 63.0, 2.5,  5, 24.0, 1, 1),
]

# executemany() inserts ALL rows at once — much faster than a loop
# The ? marks are placeholders — Python fills them safely (prevents SQL injection)
cursor.executemany("""
    INSERT INTO students
        (name, gender, attendance_pct, study_hours, assignments, internal_marks, backlogs, at_risk)
    VALUES
        (?, ?, ?, ?, ?, ?, ?, ?)
""", sample_students)

# IMPORTANT: You must call commit() to actually save the data
# Without this, changes are lost when the program ends
connection.commit()

print(f"✅ Inserted {len(sample_students)} student records!")


# ─────────────────────────────────────────────────────────
# STEP 1D: Read and display the data to verify
# ─────────────────────────────────────────────────────────
# fetchall() returns all rows as a list of tuples
cursor.execute("SELECT * FROM students")
rows = cursor.fetchall()

print("\n📋 Student Records in Database:")
print("-" * 85)
print(f"{'ID':<5} {'Name':<20} {'Gender':<8} {'Attend%':<9} {'StudyHrs':<10} {'Assign':<8} {'Marks':<8} {'Backlogs':<10} {'At Risk'}")
print("-" * 85)

for row in rows:
    student_id, name, gender, attend, study, assign, marks, backlogs, risk = row
    risk_label = "⚠️  YES" if risk == 1 else "✅  NO"
    print(f"{student_id:<5} {name:<20} {gender:<8} {attend:<9} {study:<10} {assign:<8} {marks:<8} {backlogs:<10} {risk_label}")

print("-" * 85)

# Count at-risk vs safe
cursor.execute("SELECT at_risk, COUNT(*) FROM students GROUP BY at_risk")
counts = cursor.fetchall()
for label, count in counts:
    status = "At Risk" if label == 1 else "Not At Risk"
    print(f"  {status}: {count} students")


# ─────────────────────────────────────────────────────────
# STEP 1E: Always close the connection when done
# ─────────────────────────────────────────────────────────
connection.close()
print("\n✅ Database connection closed. Setup complete!")
print(f"📁 Your database file is saved as: {os.path.abspath(db_path)}")
print("\n👉 Next step: Run 'step2_eda.py' to explore and visualize the data!")
