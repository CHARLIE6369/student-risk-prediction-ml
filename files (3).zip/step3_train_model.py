"""
==============================================
STUDENT PERFORMANCE PREDICTION SYSTEM
Step 3: Train the Machine Learning Model
==============================================

HOW TO RUN:
    python step3_train_model.py

This script will:
1. Load student data from the database
2. Prepare features (X) and target (y)
3. Train 2 models: Logistic Regression & Random Forest
4. Compare their accuracy
5. Save the best model as 'model.pkl' for use in Flask app

REQUIREMENTS:
    pip install scikit-learn joblib pandas
"""

import sqlite3
import pandas as pd
import joblib
import os
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, classification_report,
                             confusion_matrix, roc_auc_score)

print("=" * 55)
print("  STUDENT PERFORMANCE PREDICTION — MODEL TRAINING")
print("=" * 55)


# ─────────────────────────────────────────────────────────
# STEP 3A: Load data from database
# ─────────────────────────────────────────────────────────
connection = sqlite3.connect("students.db")
df = pd.read_sql_query("SELECT * FROM students", connection)
connection.close()

print(f"\n✅ Loaded {len(df)} student records from database")


# ─────────────────────────────────────────────────────────
# STEP 3B: Prepare features and target
# ─────────────────────────────────────────────────────────
# Features (X) = columns the model LEARNS FROM
# Target  (y) = column the model PREDICTS

# Convert gender text to numbers: Male=1, Female=0
# ML models only understand numbers, not text
le = LabelEncoder()
df['gender_encoded'] = le.fit_transform(df['gender'])
# Male → 1, Female → 0

# Select feature columns — we drop student_id, name, gender (text), risk label, risk label text
feature_columns = [
    'attendance_pct',    # attendance percentage
    'study_hours',       # study hours per day
    'assignments',       # assignments submitted
    'internal_marks',    # internal exam marks
    'backlogs',          # number of failed subjects
    'gender_encoded'     # gender as number
]

X = df[feature_columns]   # input features
y = df['at_risk']         # target: 0 or 1

print(f"✅ Features selected: {feature_columns}")
print(f"✅ Target column: at_risk (0 = safe, 1 = at risk)")


# ─────────────────────────────────────────────────────────
# STEP 3C: Split data into Training and Testing sets
# ─────────────────────────────────────────────────────────
# We train on 80% of data, test on remaining 20%
# test_size=0.2 means 20% goes to testing
# random_state=42 means we get same split every time we run
# stratify=y ensures both splits have equal ratio of 0s and 1s

X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

print(f"\n✅ Data Split:")
print(f"   Training samples : {len(X_train)} students")
print(f"   Testing  samples : {len(X_test)} students")


# ─────────────────────────────────────────────────────────
# STEP 3D: Train Model 1 — Logistic Regression
# ─────────────────────────────────────────────────────────
# Logistic Regression is simple and fast
# Good baseline model for binary classification (yes/no problems)

print("\n🤖 Training Model 1: Logistic Regression...")
lr_model = LogisticRegression(random_state=42, max_iter=1000)
lr_model.fit(X_train, y_train)   # TRAIN: model learns from training data

# PREDICT: model guesses on test data it has never seen
lr_predictions = lr_model.predict(X_test)
lr_accuracy = accuracy_score(y_test, lr_predictions)
lr_auc = roc_auc_score(y_test, lr_model.predict_proba(X_test)[:, 1])

print(f"   Accuracy : {lr_accuracy * 100:.1f}%")
print(f"   AUC Score: {lr_auc:.3f}")


# ─────────────────────────────────────────────────────────
# STEP 3E: Train Model 2 — Random Forest
# ─────────────────────────────────────────────────────────
# Random Forest builds many decision trees and combines them
# Usually more accurate than Logistic Regression
# n_estimators = number of trees to build

print("\n🤖 Training Model 2: Random Forest...")
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)

rf_predictions = rf_model.predict(X_test)
rf_accuracy = accuracy_score(y_test, rf_predictions)
rf_auc = roc_auc_score(y_test, rf_model.predict_proba(X_test)[:, 1])

print(f"   Accuracy : {rf_accuracy * 100:.1f}%")
print(f"   AUC Score: {rf_auc:.3f}")


# ─────────────────────────────────────────────────────────
# STEP 3F: Compare models and pick the best one
# ─────────────────────────────────────────────────────────
print("\n" + "=" * 45)
print("📊 MODEL COMPARISON:")
print("=" * 45)
print(f"  Logistic Regression  → {lr_accuracy * 100:.1f}% accuracy")
print(f"  Random Forest        → {rf_accuracy * 100:.1f}% accuracy")

# Pick whichever model has higher accuracy
if rf_accuracy >= lr_accuracy:
    best_model = rf_model
    best_predictions = rf_predictions
    best_name = "Random Forest"
else:
    best_model = lr_model
    best_predictions = lr_predictions
    best_name = "Logistic Regression"

print(f"\n🏆 Best Model: {best_name}")
print("=" * 45)


# ─────────────────────────────────────────────────────────
# STEP 3G: Detailed report of best model
# ─────────────────────────────────────────────────────────
# Classification report shows:
# Precision = of all students we predicted at-risk, how many really were?
# Recall    = of all actual at-risk students, how many did we catch?
# F1-Score  = balance between precision and recall

print(f"\n📋 Detailed Report for {best_name}:")
print("-" * 45)
print(classification_report(y_test, best_predictions,
                             target_names=["Not At Risk", "At Risk"]))


# ─────────────────────────────────────────────────────────
# STEP 3H: Save charts
# ─────────────────────────────────────────────────────────
os.makedirs("charts", exist_ok=True)
sns.set_theme(style="whitegrid")

# Chart 5: Confusion Matrix
# Shows: how many predictions were correct vs wrong
cm = confusion_matrix(y_test, best_predictions)
plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=["Not At Risk", "At Risk"],
            yticklabels=["Not At Risk", "At Risk"],
            linewidths=1)
plt.title(f"Confusion Matrix — {best_name}", fontsize=13, fontweight='bold', pad=12)
plt.ylabel("Actual Label", fontsize=11)
plt.xlabel("Predicted Label", fontsize=11)
plt.tight_layout()
plt.savefig("charts/chart5_confusion_matrix.png")
plt.close()
print("✅ Chart 5 saved: charts/chart5_confusion_matrix.png")

# Chart 6: Feature Importance (only for Random Forest)
if best_name == "Random Forest":
    importances = pd.Series(best_model.feature_importances_, index=feature_columns)
    importances = importances.sort_values(ascending=True)

    plt.figure(figsize=(7, 4))
    colors = ["#e74c3c" if v == importances.max() else "#3498db" for v in importances]
    importances.plot(kind='barh', color=colors, edgecolor='white')
    plt.title("Feature Importance — Which factors matter most?",
              fontsize=13, fontweight='bold', pad=12)
    plt.xlabel("Importance Score", fontsize=11)
    plt.tight_layout()
    plt.savefig("charts/chart6_feature_importance.png")
    plt.close()
    print("✅ Chart 6 saved: charts/chart6_feature_importance.png")

    # Print feature importance as text too
    print("\n📌 Feature Importance (most to least):")
    for feat, score in importances.sort_values(ascending=False).items():
        bar = "█" * int(score * 50)
        print(f"   {feat:<20} {bar} {score:.3f}")


# ─────────────────────────────────────────────────────────
# STEP 3I: Save the best model to a file
# ─────────────────────────────────────────────────────────
# joblib.dump() saves the trained model as a .pkl file
# Later, our Flask app will load this file to make predictions
# without having to retrain the model every time

os.makedirs("model", exist_ok=True)
joblib.dump(best_model, "model/model.pkl")
joblib.dump(feature_columns, "model/feature_columns.pkl")

print(f"\n✅ Model saved to: model/model.pkl")
print(f"✅ Feature list saved to: model/feature_columns.pkl")


# ─────────────────────────────────────────────────────────
# STEP 3J: Test the saved model with a sample prediction
# ─────────────────────────────────────────────────────────
# Let's simulate predicting for a NEW student not in our data
print("\n" + "=" * 55)
print("🧪 TEST: Predicting for a new student...")
print("=" * 55)

# Load the saved model (simulating what Flask will do)
loaded_model = joblib.load("model/model.pkl")

# New student data — same order as feature_columns
# attendance=45%, study=1hr, assignments=2, marks=15, backlogs=3, gender=Male(1)
new_student = pd.DataFrame([[45.0, 1.0, 2, 15.0, 3, 1]], columns=feature_columns)

prediction = loaded_model.predict(new_student)[0]
confidence = loaded_model.predict_proba(new_student)[0]

print(f"   Attendance    : 45%")
print(f"   Study Hours   : 1 hr/day")
print(f"   Assignments   : 2/10")
print(f"   Internal Marks: 15/50")
print(f"   Backlogs      : 3")
print(f"   Gender        : Male")
print(f"\n   Prediction    : {'⚠️  AT RISK' if prediction == 1 else '✅  NOT AT RISK'}")
print(f"   Confidence    : {max(confidence) * 100:.1f}%")

print("\n✅ Step 3 Complete!")
print("👉 Next step: Run 'step4_flask_app.py' to build the web app!")
