"""
==============================================
STUDENT PERFORMANCE PREDICTION SYSTEM
Step 2: Data Analysis & Visualization (EDA)
==============================================

HOW TO RUN:
    python step2_eda.py

This script will:
1. Load student data from the database
2. Show basic statistics about the data
3. Save 4 charts as image files you can include in your project report

REQUIREMENTS:
    pip install pandas matplotlib seaborn
"""

import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# ─────────────────────────────────────────────────────────
# STEP 2A: Load data from database into a Pandas DataFrame
# ─────────────────────────────────────────────────────────
# A DataFrame is like an Excel table in Python
# pd.read_sql_query() runs SQL and gives back a DataFrame directly

connection = sqlite3.connect("students.db")

df = pd.read_sql_query("SELECT * FROM students", connection)

connection.close()

print("✅ Data loaded from database!")
print(f"   Total students: {len(df)}")
print(f"   Columns: {list(df.columns)}")


# ─────────────────────────────────────────────────────────
# STEP 2B: Basic statistics
# ─────────────────────────────────────────────────────────
# describe() gives count, mean, min, max, etc. for every column
print("\n📊 Basic Statistics:")
print("-" * 50)
print(df.describe().round(2))

# Check for missing values — important before ML!
print("\n🔍 Missing Values in Each Column:")
print(df.isnull().sum())

# Value counts for target column
print("\n🎯 Target Column (at_risk) Distribution:")
counts = df['at_risk'].value_counts()
print(f"   Not At Risk (0): {counts[0]} students")
print(f"   At Risk     (1): {counts[1]} students")


# ─────────────────────────────────────────────────────────
# STEP 2C: Create charts folder
# ─────────────────────────────────────────────────────────
# We'll save all charts as PNG files so you can use them in your report
os.makedirs("charts", exist_ok=True)

# Set a nice style for all charts
sns.set_theme(style="whitegrid", palette="Set2")
plt.rcParams['figure.dpi'] = 120


# ─────────────────────────────────────────────────────────
# CHART 1: At-Risk vs Not At-Risk (Bar Chart)
# ─────────────────────────────────────────────────────────
# This shows how many students are at risk vs safe
plt.figure(figsize=(6, 4))

colors = ["#2ecc71", "#e74c3c"]  # green for safe, red for at-risk
labels = ["Not At Risk", "At Risk"]
values = [counts[0], counts[1]]

bars = plt.bar(labels, values, color=colors, width=0.4, edgecolor="white", linewidth=1.5)

# Add number labels on top of each bar
for bar, val in zip(bars, values):
    plt.text(bar.get_x() + bar.get_width() / 2,
             bar.get_height() + 0.2,
             str(val), ha='center', fontsize=13, fontweight='bold')

plt.title("Student Risk Distribution", fontsize=14, fontweight='bold', pad=12)
plt.ylabel("Number of Students", fontsize=11)
plt.ylim(0, max(values) + 2)
plt.tight_layout()
plt.savefig("charts/chart1_risk_distribution.png")
plt.close()
print("\n✅ Chart 1 saved: charts/chart1_risk_distribution.png")


# ─────────────────────────────────────────────────────────
# CHART 2: Attendance % vs At Risk (Box Plot)
# ─────────────────────────────────────────────────────────
# Box plots show the spread of data
# We want to see if low attendance = more at risk
plt.figure(figsize=(7, 4))

# Map 0/1 to readable labels for the chart
df['Risk Label'] = df['at_risk'].map({0: 'Not At Risk', 1: 'At Risk'})

sns.boxplot(
    data=df,
    x='Risk Label',
    y='attendance_pct',
    palette={"Not At Risk": "#2ecc71", "At Risk": "#e74c3c"}
)

plt.title("Attendance % by Risk Category", fontsize=14, fontweight='bold', pad=12)
plt.xlabel("Risk Category", fontsize=11)
plt.ylabel("Attendance Percentage", fontsize=11)
plt.tight_layout()
plt.savefig("charts/chart2_attendance_vs_risk.png")
plt.close()
print("✅ Chart 2 saved: charts/chart2_attendance_vs_risk.png")


# ─────────────────────────────────────────────────────────
# CHART 3: Study Hours vs Internal Marks (Scatter Plot)
# ─────────────────────────────────────────────────────────
# Scatter plot shows relationship between 2 numeric variables
# Color = at risk or not, so we can see patterns
plt.figure(figsize=(7, 5))

colors_map = {0: "#2ecc71", 1: "#e74c3c"}

for risk_val, group in df.groupby('at_risk'):
    label = "Not At Risk" if risk_val == 0 else "At Risk"
    plt.scatter(
        group['study_hours'],
        group['internal_marks'],
        c=colors_map[risk_val],
        label=label,
        alpha=0.8,       # slight transparency
        s=80,            # dot size
        edgecolors='white',
        linewidths=0.5
    )

plt.title("Study Hours vs Internal Marks", fontsize=14, fontweight='bold', pad=12)
plt.xlabel("Study Hours Per Day", fontsize=11)
plt.ylabel("Internal Marks (out of 50)", fontsize=11)
plt.legend(fontsize=10)
plt.tight_layout()
plt.savefig("charts/chart3_studyhours_vs_marks.png")
plt.close()
print("✅ Chart 3 saved: charts/chart3_studyhours_vs_marks.png")


# ─────────────────────────────────────────────────────────
# CHART 4: Correlation Heatmap
# ─────────────────────────────────────────────────────────
# A heatmap shows how strongly each feature is related to others
# Values close to 1 or -1 = strong relationship
# This helps us pick the best features for our ML model

plt.figure(figsize=(8, 6))

# Select only numeric columns for correlation
numeric_cols = ['attendance_pct', 'study_hours', 'assignments',
                'internal_marks', 'backlogs', 'at_risk']

corr_matrix = df[numeric_cols].corr().round(2)

sns.heatmap(
    corr_matrix,
    annot=True,          # show numbers inside boxes
    fmt=".2f",           # 2 decimal places
    cmap="RdYlGn_r",     # red=negative, green=positive
    linewidths=0.5,
    square=True,
    cbar_kws={"shrink": 0.8}
)

plt.title("Feature Correlation Heatmap", fontsize=14, fontweight='bold', pad=12)
plt.tight_layout()
plt.savefig("charts/chart4_correlation_heatmap.png")
plt.close()
print("✅ Chart 4 saved: charts/chart4_correlation_heatmap.png")


# ─────────────────────────────────────────────────────────
# STEP 2D: Key Insights Summary
# ─────────────────────────────────────────────────────────
print("\n" + "=" * 55)
print("📌 KEY INSIGHTS FROM YOUR DATA:")
print("=" * 55)

avg_attend_safe    = df[df['at_risk'] == 0]['attendance_pct'].mean()
avg_attend_risk    = df[df['at_risk'] == 1]['attendance_pct'].mean()
avg_marks_safe     = df[df['at_risk'] == 0]['internal_marks'].mean()
avg_marks_risk     = df[df['at_risk'] == 1]['internal_marks'].mean()
avg_study_safe     = df[df['at_risk'] == 0]['study_hours'].mean()
avg_study_risk     = df[df['at_risk'] == 1]['study_hours'].mean()

print(f"  Avg Attendance  — Safe: {avg_attend_safe:.1f}%  |  At Risk: {avg_attend_risk:.1f}%")
print(f"  Avg Marks       — Safe: {avg_marks_safe:.1f}    |  At Risk: {avg_marks_risk:.1f}")
print(f"  Avg Study Hours — Safe: {avg_study_safe:.1f}    |  At Risk: {avg_study_risk:.1f}")
print("=" * 55)
print("\n✅ Step 2 Complete!")
print("📁 All 4 charts saved in the 'charts' folder")
print("👉 Next step: Run 'step3_train_model.py' to train the ML model!")
