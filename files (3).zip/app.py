"""
==============================================
STUDENT PERFORMANCE PREDICTION SYSTEM
Step 4: Flask Web Application
==============================================

HOW TO RUN:
    python app.py

Then open your browser and go to:
    http://127.0.0.1:5000

REQUIREMENTS:
    pip install flask joblib pandas scikit-learn
"""

from flask import Flask, render_template, request, jsonify
import joblib
import pandas as pd
import sqlite3
from datetime import datetime

# ─────────────────────────────────────────────────────────
# Initialize Flask app
# ─────────────────────────────────────────────────────────
# Flask(__name__) creates the web app
# __name__ tells Flask where to find templates and static files
app = Flask(__name__)

# ─────────────────────────────────────────────────────────
# Load the trained model and feature list
# ─────────────────────────────────────────────────────────
# We load these ONCE when the app starts — not on every request
model = joblib.load("model/model.pkl")
feature_columns = joblib.load("model/feature_columns.pkl")

print("✅ Model loaded successfully!")
print(f"   Features: {feature_columns}")


# ─────────────────────────────────────────────────────────
# Helper: save prediction to database
# ─────────────────────────────────────────────────────────
def save_prediction(student_id, predicted_label, confidence):
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO predictions (student_id, predicted_label, confidence, predicted_on)
        VALUES (?, ?, ?, ?)
    """, (student_id, predicted_label, confidence, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    conn.commit()
    conn.close()


# ─────────────────────────────────────────────────────────
# ROUTE 1: Home page — shows the prediction form
# ─────────────────────────────────────────────────────────
# @app.route() tells Flask what URL triggers this function
# '/' means the homepage: http://127.0.0.1:5000/
@app.route('/')
def home():
    return render_template('index.html')


# ─────────────────────────────────────────────────────────
# ROUTE 2: Predict — handles form submission
# ─────────────────────────────────────────────────────────
# methods=['POST'] means this route only accepts form submissions
# GET = loading a page, POST = submitting data
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get values from the HTML form
        # request.form['field_name'] reads what the user typed
        name           = request.form['name']
        gender         = request.form['gender']
        attendance     = float(request.form['attendance'])
        study_hours    = float(request.form['study_hours'])
        assignments    = int(request.form['assignments'])
        internal_marks = float(request.form['internal_marks'])
        backlogs       = int(request.form['backlogs'])

        # Convert gender to number (same as training)
        gender_encoded = 1 if gender == 'Male' else 0

        # Build input DataFrame — same column order as training
        input_data = pd.DataFrame([[
            attendance, study_hours, assignments,
            internal_marks, backlogs, gender_encoded
        ]], columns=feature_columns)

        # Make prediction
        prediction = model.predict(input_data)[0]          # 0 or 1
        confidence  = model.predict_proba(input_data)[0]   # [prob_0, prob_1]
        conf_score  = round(max(confidence) * 100, 1)      # e.g. 87.5

        # Save to database
        save_prediction(None, int(prediction), conf_score)

        # Build result message
        if prediction == 1:
            result = "AT RISK"
            message = f"{name} is likely to struggle academically. Immediate counselling recommended."
            color = "danger"
            icon = "⚠️"
        else:
            result = "NOT AT RISK"
            message = f"{name} is performing well. Keep up the good work!"
            color = "success"
            icon = "✅"

        return render_template('index.html',
            prediction=result,
            message=message,
            color=color,
            icon=icon,
            confidence=conf_score,
            name=name,
            # Pass back form values so they stay filled
            attendance=attendance,
            study_hours=study_hours,
            assignments=assignments,
            internal_marks=internal_marks,
            backlogs=backlogs,
            gender=gender
        )

    except Exception as e:
        return render_template('index.html', error=str(e))


# ─────────────────────────────────────────────────────────
# ROUTE 3: Dashboard — shows all students and predictions
# ─────────────────────────────────────────────────────────
@app.route('/dashboard')
def dashboard():
    conn = sqlite3.connect("students.db")

    # Load all students
    students_df = pd.read_sql_query("SELECT * FROM students", conn)

    # Summary stats
    total      = len(students_df)
    at_risk    = int(students_df['at_risk'].sum())
    safe       = total - at_risk
    avg_attend = round(students_df['attendance_pct'].mean(), 1)
    avg_marks  = round(students_df['internal_marks'].mean(), 1)

    # Convert to list of dicts for HTML template
    students = students_df.to_dict(orient='records')

    conn.close()

    return render_template('index.html',
        page='dashboard',
        students=students,
        total=total,
        at_risk=at_risk,
        safe=safe,
        avg_attend=avg_attend,
        avg_marks=avg_marks
    )


# ─────────────────────────────────────────────────────────
# Start the app
# ─────────────────────────────────────────────────────────
# debug=True means:
#   - Server auto-restarts when you save changes
#   - Shows helpful error messages in browser
# NEVER use debug=True in production (live website)
if __name__ == '__main__':
    print("\n🚀 Starting Student Prediction Web App...")
    print("   Open your browser and go to: http://127.0.0.1:5000")
    print("   Press Ctrl+C to stop the server\n")
    app.run(debug=True)
